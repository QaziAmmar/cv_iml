# cv_iml
A Computer Vision library for Intelligent Machine Labs, Information Technology University. 
